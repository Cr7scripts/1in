using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;

namespace EAX;

internal enum ToneMode { None, Dll }

/// <summary>
/// Equalizer + bass boost. They run as real DSP inside the audio engine (eax_audio.dll, api version 2),
/// independent of Voicemeeter or any other program.
/// </summary>
internal static class ToneBackend
{
    [DllImport("eax_audio.dll", CallingConvention = CallingConvention.Cdecl)] private static extern int eax_api_version();
    [DllImport("eax_audio.dll", CallingConvention = CallingConvention.Cdecl)] private static extern void eax_set_eq_enabled(int on);
    [DllImport("eax_audio.dll", CallingConvention = CallingConvention.Cdecl)] private static extern void eax_set_eq_gain(int band, int tenthDb);
    [DllImport("eax_audio.dll", CallingConvention = CallingConvention.Cdecl)] private static extern void eax_set_bass(int on, int level, int cutoffHz);

    private static bool? _supported;

    internal static ToneMode Mode { get; private set; } = ToneMode.None;
    internal static string Status { get; private set; } = "Not applied yet.";

    internal static bool Supported
    {
        get
        {
            if (_supported is null)
            {
                try { _supported = eax_api_version() >= 2; }
                catch { _supported = false; }
            }
            return _supported.Value;
        }
    }

    /// <summary>Pushes the whole equalizer / bass state to the audio engine.</summary>
    internal static void Refresh(MainForm.UserSettings s)
    {
        try
        {
            if (s.EqGains.Length != 10) s.EqGains = new int[10];
            if (s.EqCustom.Length != 10) s.EqCustom = new int[10];
            if (!Supported)
            {
                Mode = ToneMode.None;
                Status = "this eax_audio.dll is the old one - build the new DLL (BUILD_DLL.txt)";
                return;
            }
            eax_set_eq_enabled(s.EqEnabled ? 1 : 0);
            for (int band = 0; band < 10; band++) eax_set_eq_gain(band, s.EqGains[band]);
            eax_set_bass(s.BassEnabled ? 1 : 0, s.BassLevel, s.BassCutoff);
            Mode = ToneMode.Dll;
            Status = "Equalizer and bass boost run inside the audio engine.";
        }
        catch (Exception ex)
        {
            Mode = ToneMode.None;
            Status = ex.Message;
        }
    }

    internal static void ApplyAll(MainForm.UserSettings s) => Refresh(s);

    internal static void Shutdown() { }
}

/// <summary>Base for the artwork-driven panels: hover glow, click handling, dragging, fades.</summary>
internal abstract class ArtWindow : Form
{
    protected const double K = 0.625;   // the artwork is 1024x572, shown at 640x358

    protected static Rectangle R(int x0, int y0, int x1, int y1) =>
        Rectangle.FromLTRB((int)Math.Round(x0 * K), (int)Math.Round(y0 * K), (int)Math.Round(x1 * K), (int)Math.Round(y1 * K));

    protected static PointF P(double x, double y) => new((float)(x * K), (float)(y * K));

    protected static readonly Color TextColor = Color.FromArgb(214, 214, 218);
    protected static readonly Color DimColor = Color.FromArgb(150, 152, 158);

    protected readonly Cursor Hand;
    protected readonly Font SmallFont = new("Segoe UI", 7.5f);
    protected readonly Font TextFont = new("Segoe UI", 9f);
    protected const TextFormatFlags LeftFlags = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine
        | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding;
    protected const TextFormatFlags CenterFlags = TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter
        | TextFormatFlags.SingleLine | TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding;

    private readonly Bitmap _art;
    private readonly List<(string Id, Rectangle Rect, bool Glow)> _hots = new();
    private readonly Dictionary<string, float> _glow = new();
    private readonly System.Windows.Forms.Timer _glowTimer = new() { Interval = 15 };
    private string? _hover, _pressed;
    private bool _sliding;

    protected ArtWindow(string assets, string artFile, string title, Cursor hand)
    {
        _art = new Bitmap(Path.Combine(assets, artFile));
        Hand = hand;
        Text = title;
        AutoScaleMode = AutoScaleMode.None;
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.CenterParent;
        ShowInTaskbar = true;
        DoubleBuffered = true;
        KeyPreview = true;
        ClientSize = _art.Size;
        BackgroundImage = _art;
        BackgroundImageLayout = ImageLayout.Stretch;
        Opacity = 0;
        string icon = Path.Combine(assets, "AppIcon.ico");
        if (File.Exists(icon)) Icon = new Icon(icon);

        _glowTimer.Tick += (_, _) =>
        {
            bool moving = false;
            foreach (var key in _glow.Keys.ToList())
            {
                float goal = key == _hover ? 1f : 0f;
                float next = _glow[key] + (goal - _glow[key]) * 0.35f;
                if (Math.Abs(goal - next) < 0.02f) next = goal;
                if (next != _glow[key]) { _glow[key] = next; moving = true; }
            }
            if (moving) Invalidate(); else _glowTimer.Stop();
        };
    }

    protected void AddHot(string id, Rectangle rect, bool glow = true)
    {
        _hots.Add((id, rect, glow));
        _glow[id] = 0f;
    }

    // ---------- hooks for the derived windows ----------
    protected abstract void OnHotClick(string id);
    protected virtual bool BeginSlider(Point p) => false;
    protected virtual void DragSlider(Point p) { }
    protected virtual void EndSlider() { }
    protected virtual bool OverSlider(Point p) => false;
    protected virtual void RightClick(Point p) { }
    protected virtual void PaintOverlay(Graphics g) { }
    protected virtual void Opened() { }

    protected string? HitHot(Point p)
    {
        foreach (var hot in _hots) if (hot.Rect.Contains(p)) return hot.Id;
        return null;
    }

    protected void CloseFaded()
    {
        int step = 0;
        var fade = new System.Windows.Forms.Timer { Interval = 15 };
        fade.Tick += (_, _) =>
        {
            step++; Opacity = Math.Max(0, 1 - step / 8.0);
            if (step >= 8) { fade.Stop(); fade.Dispose(); Close(); }
        };
        fade.Start();
    }

    protected override void OnShown(EventArgs e)
    {
        base.OnShown(e);
        int step = 0;
        var fade = new System.Windows.Forms.Timer { Interval = 15 };
        fade.Tick += (_, _) =>
        {
            step++; Opacity = Math.Min(1.0, step / 10.0);
            if (step >= 10) { fade.Stop(); fade.Dispose(); }
        };
        fade.Start();
        Opened();
    }

    // ---------- mouse ----------
    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (e.Button == MouseButtons.Right) { RightClick(e.Location); return; }
        if (e.Button != MouseButtons.Left) return;
        if (BeginSlider(e.Location)) { _sliding = true; return; }
        string? hit = HitHot(e.Location);
        if (hit is null) { NativeWindowDrag.Begin(this); return; }
        _pressed = hit; Invalidate();
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (_sliding) { DragSlider(e.Location); return; }
        string? hit = HitHot(e.Location);
        Cursor = hit is not null || OverSlider(e.Location) ? Hand : Cursors.Default;
        if (hit == _hover) return;
        _hover = hit;
        _glowTimer.Start();
    }

    protected override void OnMouseLeave(EventArgs e)
    {
        base.OnMouseLeave(e);
        _hover = null; Cursor = Cursors.Default; _glowTimer.Start();
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        base.OnMouseUp(e);
        if (_sliding) { _sliding = false; EndSlider(); Invalidate(); return; }
        string? pressed = _pressed; _pressed = null; Invalidate();
        if (e.Button != MouseButtons.Left || pressed is null || HitHot(e.Location) != pressed) return;
        OnHotClick(pressed);
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
        base.OnKeyDown(e);
        if (e.KeyCode == Keys.Escape) CloseFaded();
    }

    // ---------- painting ----------
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        PaintOverlay(g);
        foreach (var hot in _hots)
        {
            if (!hot.Glow) continue;
            float glow = _glow[hot.Id];
            bool pressed = hot.Id == _pressed;
            if (glow <= 0.01f && !pressed) continue;
            var area = hot.Rect; area.Inflate(-1, -1);
            using var path = RoundedRect(area, 6);
            using var brush = new SolidBrush(pressed ? Color.FromArgb(80, 0, 0, 0) : Color.FromArgb((int)(36 * glow), 255, 255, 255));
            g.FillPath(brush, path);
        }
    }

    protected static GraphicsPath RoundedRect(RectangleF r, float radius)
    {
        float d = radius * 2;
        var path = new GraphicsPath();
        path.AddArc(r.Left, r.Top, d, d, 180, 90);
        path.AddArc(r.Right - d, r.Top, d, d, 270, 90);
        path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
        path.AddArc(r.Left, r.Bottom - d, d, d, 90, 90);
        path.CloseFigure();
        return path;
    }

    /// <summary>Metal check box that fully covers the one baked into the artwork.</summary>
    protected static void DrawCheck(Graphics g, PointF center, bool on)
    {
        var box = new RectangleF(center.X - 9.5f, center.Y - 9.5f, 19f, 19f);
        using (var path = RoundedRect(box, 3.5f))
        {
            using var fill = new LinearGradientBrush(box, Color.FromArgb(84, 86, 92), Color.FromArgb(44, 46, 50), LinearGradientMode.Vertical);
            g.FillPath(fill, path);
            using var border = new Pen(Color.FromArgb(14, 14, 16), 1.2f);
            g.DrawPath(border, path);
        }
        var inner = RectangleF.Inflate(box, -1.5f, -1.5f);
        using (var path = RoundedRect(inner, 2.5f))
        using (var shine = new Pen(Color.FromArgb(46, 255, 255, 255), 1f))
            g.DrawPath(shine, path);
        if (!on) return;
        using var tick = new Pen(Color.FromArgb(238, 240, 246), 2.3f) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round };
        g.DrawLines(tick, new[]
        {
            new PointF(box.Left + box.Width * 0.22f, box.Top + box.Height * 0.52f),
            new PointF(box.Left + box.Width * 0.43f, box.Top + box.Height * 0.74f),
            new PointF(box.Left + box.Width * 0.79f, box.Top + box.Height * 0.27f),
        });
    }

    /// <summary>Small line that says which engine is applying the tone (or why none is).</summary>
    protected void DrawToneStatus(Graphics g, Rectangle area)
    {
        if (ToneBackend.Mode == ToneMode.Dll) return;
        TextRenderer.DrawText(g, "Needs the new eax_audio.dll (BUILD_DLL.txt)", SmallFont, area,
            Color.FromArgb(230, 120, 110), CenterFlags | TextFormatFlags.EndEllipsis);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) { _glowTimer.Dispose(); _art.Dispose(); SmallFont.Dispose(); TextFont.Dispose(); }
        base.Dispose(disposing);
    }
}

/// <summary>10-band graphic equalizer.</summary>
internal sealed class EqualizerForm : ArtWindow
{
    private const int ZeroY = 337;                 // art y of 0 dB
    private const double PixelsPerDb = 109.0 / 12.0;
    private static readonly double[] CenterX = Enumerable.Range(0, 10).Select(i => 163.5 + (860.1 - 163.5) / 9.0 * i).ToArray();

    private static readonly string[] PresetNames = ["EQ Flat", "Bass Boost", "Voice Clarity", "Treble Boost", "Radio", "Deep Voice", "Custom"];
    private static readonly int[][] PresetGains =
    [
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [8, 7, 5, 3, 1, 0, 0, 0, 0, 0],
        [-12, -9, -5, -2, 0, 2, 4, 5, 3, 0],
        [0, 0, 0, 0, 0, 1, 3, 5, 7, 8],
        [-12, -10, -6, 0, 4, 6, 5, 2, -4, -8],
        [7, 6, 5, 3, 1, 0, -1, -2, -3, -4],
    ];

    private readonly MainForm.UserSettings _s;
    private readonly Action _save;
    private readonly string _mic;
    private int _drag = -1;

    internal EqualizerForm(string assets, Cursor hand, MainForm.UserSettings settings, Action save, string micName)
        : base(assets, "Equalizer.png", "Equalizer", hand)
    {
        _s = settings; _save = save; _mic = micName;
        if (_s.EqGains.Length != 10) _s.EqGains = new int[10];
        if (_s.EqCustom.Length != 10) _s.EqCustom = new int[10];
        AddHot("close", R(960, 12, 1004, 48));
        AddHot("min", R(916, 18, 954, 48));
        AddHot("check", R(26, 134, 228, 170), glow: false);
        AddHot("presets", R(527, 131, 848, 170));
        AddHot("save", R(863, 131, 923, 170));
        AddHot("delete", R(935, 131, 996, 170));
        AddHot("default", R(40, 536, 222, 572));
    }

    protected override void Opened()
    {
        ToneBackend.Refresh(_s);
        if (ToneBackend.Mode == ToneMode.None)
            MessageBox.Show(this, "The equalizer needs the new eax_audio.dll (it contains the real EQ engine).\nSee BUILD_DLL.txt - GitHub builds it for you for free.\n\nالإيكولايزر يحتاج eax_audio.dll الجديد. الخطوات في BUILD_DLL.txt.",
                "Equalizer", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void ApplyAll()
    {
        ToneBackend.Refresh(_s);
        _save();
        Invalidate();
    }

    private void LoadPreset(string name)
    {
        int[] source = name == "Custom" ? _s.EqCustom : PresetGains[Math.Max(0, Array.IndexOf(PresetNames, name))];
        for (int band = 0; band < 10; band++) _s.EqGains[band] = name == "Custom" ? source[band] : source[band] * 10;
        _s.EqPreset = name;
        ApplyAll();
    }

    protected override void OnHotClick(string id)
    {
        switch (id)
        {
            case "close": CloseFaded(); break;
            case "min": WindowState = FormWindowState.Minimized; break;
            case "check": _s.EqEnabled = !_s.EqEnabled; ApplyAll(); break;
            case "default": LoadPreset("EQ Flat"); break;
            case "save":
                Array.Copy(_s.EqGains, _s.EqCustom, 10);
                _s.EqPreset = "Custom";
                ApplyAll();
                break;
            case "delete":
                Array.Clear(_s.EqCustom, 0, 10);
                LoadPreset("EQ Flat");
                break;
            case "presets":
                {
                    var field = R(527, 131, 848, 170);
                    using var drop = new AudioSettingsForm.DropList([.. PresetNames], Math.Max(0, Array.IndexOf(PresetNames, _s.EqPreset)), field.Width, Hand);
                    drop.Location = PointToScreen(new Point(field.Left, field.Bottom - 2));
                    drop.ShowDialog(this);
                    if (drop.Chosen >= 0) LoadPreset(PresetNames[drop.Chosen]);
                    break;
                }
        }
    }

    // ---------- sliders ----------
    private int BandAt(Point p)
    {
        double x = p.X / K, y = p.Y / K;
        if (y < 205 || y > 470) return -1;
        for (int i = 0; i < 10; i++) if (Math.Abs(x - CenterX[i]) <= 34) return i;
        return -1;
    }

    protected override bool OverSlider(Point p) => BandAt(p) >= 0;

    private void SetFromY(int band, Point p)
    {
        double db = Math.Clamp((ZeroY - p.Y / K) / PixelsPerDb, -12, 12);
        int tenths = (int)Math.Round(db * 2) * 5;          // 0.5 dB steps
        if (tenths == _s.EqGains[band]) return;
        _s.EqGains[band] = tenths;
        _s.EqPreset = "Custom";
        ToneBackend.Refresh(_s);
        Invalidate();
    }

    protected override bool BeginSlider(Point p)
    {
        int band = BandAt(p);
        if (band < 0) return false;
        _drag = band;
        SetFromY(band, p);
        return true;
    }

    protected override void DragSlider(Point p) { if (_drag >= 0) SetFromY(_drag, p); }

    protected override void EndSlider()
    {
        _drag = -1;
        _save();
    }

    protected override void RightClick(Point p)
    {
        int band = BandAt(p);
        if (band < 0) return;
        _s.EqGains[band] = 0;
        _s.EqPreset = "Custom";
        ApplyAll();
    }

    // ---------- painting ----------
    protected override void PaintOverlay(Graphics g)
    {
        TextRenderer.DrawText(g, _mic, TextFont, R(425, 10, 700, 44), TextColor, LeftFlags);
        TextRenderer.DrawText(g, _s.EqPreset, TextFont, R(540, 138, 810, 164), TextColor, LeftFlags);
        DrawCheck(g, P(41.5, 151), _s.EqEnabled);

        for (int band = 0; band < 10; band++)
        {
            double db = _s.EqGains[band] / 10.0;
            double yArt = ZeroY - db * PixelsPerDb;
            using (var rail = new SolidBrush(Color.FromArgb(112, 114, 120)))
                g.FillRectangle(rail, R((int)(CenterX[band] - 30), ZeroY - 1, (int)(CenterX[band] + 30), ZeroY + 2));
            DrawThumb(g, P(CenterX[band], yArt), band == _drag);
            if (band == _drag)
            {
                string label = db == 0 ? "0 dB" : $"{db:+0.0;-0.0} dB";
                var spot = P(CenterX[band], yArt - 40);
                var box = new RectangleF(spot.X - 24, spot.Y - 9, 48, 18);
                using var path = RoundedRect(box, 5);
                using var back = new SolidBrush(Color.FromArgb(225, 18, 18, 20));
                g.FillPath(back, path);
                TextRenderer.DrawText(g, label, SmallFont, Rectangle.Round(box), Color.FromArgb(235, 238, 244), CenterFlags);
            }
        }

        if (!_s.EqEnabled)
        {
            // disabled look for the slider area
            using var veil = new SolidBrush(Color.FromArgb(70, 0, 0, 0));
            g.FillRectangle(veil, R(130, 180, 1000, 515));
        }
        DrawToneStatus(g, R(440, 545, 725, 568));
    }

    private static void DrawThumb(Graphics g, PointF center, bool active)
    {
        var r = new RectangleF(center.X - 8.5f, center.Y - 15.5f, 17f, 31f);
        using var path = RoundedRect(r, 4.5f);
        using var fill = new LinearGradientBrush(r, Color.FromArgb(active ? 225 : 205, 207, 213), Color.FromArgb(78, 80, 86), LinearGradientMode.Vertical);
        g.FillPath(fill, path);
        using var border = new Pen(Color.FromArgb(18, 18, 20), 1.3f);
        g.DrawPath(border, path);
        using var grip = new Pen(Color.FromArgb(150, 20, 20, 24), 1.2f);
        g.DrawLine(grip, r.Left + 3.5f, center.Y, r.Right - 3.5f, center.Y);
        using var light = new Pen(Color.FromArgb(70, 255, 255, 255), 1f);
        g.DrawLine(light, r.Left + 3.5f, center.Y + 1.4f, r.Right - 3.5f, center.Y + 1.4f);
    }
}

/// <summary>Bass boost: on/off, level (0-100 %) and cutoff frequency (10-200 Hz).</summary>
internal sealed class BassBoostForm : ArtWindow
{
    private const int TrackLeft = 407, TrackRight = 788, LevelY = 269, CutoffY = 395;
    private const int KnobInset = 11;

    private readonly MainForm.UserSettings _s;
    private readonly Action _save;
    private readonly string _mic;
    private int _drag = -1;   // 0 = level, 1 = cutoff

    internal BassBoostForm(string assets, Cursor hand, MainForm.UserSettings settings, Action save, string micName)
        : base(assets, "BassBoost.png", "Bass Boost", hand)
    {
        _s = settings; _save = save; _mic = micName;
        AddHot("close", R(967, 10, 1007, 50));
        AddHot("min", R(872, 10, 912, 50));
        AddHot("check", R(70, 157, 232, 193), glow: false);
        AddHot("default", R(38, 520, 213, 562));
    }

    protected override void Opened()
    {
        ToneBackend.Refresh(_s);
        if (ToneBackend.Mode == ToneMode.None)
            MessageBox.Show(this, "Bass boost needs the new eax_audio.dll (it contains the real bass engine).\nSee BUILD_DLL.txt - GitHub builds it for you for free.\n\nالباس بوست يحتاج eax_audio.dll الجديد. الخطوات في BUILD_DLL.txt.",
                "Bass Boost", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void Apply()
    {
        ToneBackend.Refresh(_s);
        Invalidate();
    }

    protected override void OnHotClick(string id)
    {
        switch (id)
        {
            case "close": _save(); CloseFaded(); break;
            case "min": WindowState = FormWindowState.Minimized; break;
            case "check": _s.BassEnabled = !_s.BassEnabled; Apply(); _save(); break;
            case "default":
                _s.BassLevel = 50; _s.BassCutoff = 100; _s.BassEnabled = false;
                Apply(); _save();
                break;
        }
    }

    // ---------- sliders ----------
    private int SliderAt(Point p)
    {
        double x = p.X / K, y = p.Y / K;
        if (x < TrackLeft - 12 || x > TrackRight + 12) return -1;
        if (Math.Abs(y - LevelY) <= 22) return 0;
        if (Math.Abs(y - CutoffY) <= 22) return 1;
        return -1;
    }

    protected override bool OverSlider(Point p) => SliderAt(p) >= 0;

    private void SetFromX(int slider, Point p)
    {
        double span = TrackRight - TrackLeft - 2 * KnobInset;
        double t = Math.Clamp((p.X / K - TrackLeft - KnobInset) / span, 0, 1);
        if (slider == 0)
        {
            int level = (int)Math.Round(t * 100);
            if (level == _s.BassLevel) return;
            _s.BassLevel = level;
        }
        else
        {
            int cutoff = (int)Math.Round(10 + t * 190);
            if (cutoff == _s.BassCutoff) return;
            _s.BassCutoff = cutoff;
        }
        Apply();
    }

    protected override bool BeginSlider(Point p)
    {
        int slider = SliderAt(p);
        if (slider < 0) return false;
        _drag = slider;
        SetFromX(slider, p);
        return true;
    }

    protected override void DragSlider(Point p) { if (_drag >= 0) SetFromX(_drag, p); }

    protected override void EndSlider() { _drag = -1; _save(); }

    // ---------- painting ----------
    protected override void PaintOverlay(Graphics g)
    {
        TextRenderer.DrawText(g, _mic, TextFont, R(436, 18, 700, 44), TextColor, LeftFlags);
        DrawCheck(g, P(88.5, 174), _s.BassEnabled);

        DrawSlider(g, LevelY, (_s.BassLevel) / 100.0, $"{_s.BassLevel}%", _drag == 0);
        DrawSlider(g, CutoffY, (_s.BassCutoff - 10) / 190.0, $"{_s.BassCutoff} Hz", _drag == 1);

        DrawToneStatus(g, R(300, 470, 760, 495));
    }

    private void DrawSlider(Graphics g, int yArt, double t, string label, bool active)
    {
        float left = P(TrackLeft, 0).X, right = P(TrackRight, 0).X, y = P(0, yArt).Y;
        var groove = new RectangleF(left, y - 3.2f, right - left, 6.4f);
        using (var path = RoundedRect(groove, 3.2f))
        {
            using var back = new LinearGradientBrush(groove, Color.FromArgb(22, 23, 26), Color.FromArgb(54, 55, 60), LinearGradientMode.Vertical);
            g.FillPath(back, path);
            using var rim = new Pen(Color.FromArgb(90, 255, 255, 255), 1f);
            g.DrawPath(rim, path);
        }
        float knobX = (float)(left + (P(KnobInset, 0).X) + t * (right - left - 2 * P(KnobInset, 0).X));
        var fill = new RectangleF(groove.Left, groove.Top, Math.Max(2f, knobX - groove.Left), groove.Height);
        using (var path = RoundedRect(fill, 3.2f))
        {
            Color a = _s.BassEnabled ? Color.FromArgb(214, 216, 222) : Color.FromArgb(120, 122, 128);
            Color b = _s.BassEnabled ? Color.FromArgb(128, 130, 136) : Color.FromArgb(78, 80, 86);
            using var brush = new LinearGradientBrush(fill, a, b, LinearGradientMode.Vertical);
            g.FillPath(brush, path);
        }
        var knob = new RectangleF(knobX - 7.5f, y - 7.5f, 15f, 15f);
        using (var shadow = new SolidBrush(Color.FromArgb(70, 0, 0, 0)))
            g.FillEllipse(shadow, knob.Left + 0.8f, knob.Top + 1.4f, knob.Width, knob.Height);
        using (var brush = new LinearGradientBrush(knob, Color.FromArgb(active ? 238 : 218, 220, 226), Color.FromArgb(118, 120, 126), LinearGradientMode.Vertical))
            g.FillEllipse(brush, knob);
        using (var border = new Pen(Color.FromArgb(30, 31, 35), 1.2f))
            g.DrawEllipse(border, knob);
        TextRenderer.DrawText(g, label, SmallFont, new Rectangle((int)knobX - 30, (int)(y - 24), 60, 14), Color.FromArgb(225, 227, 233), CenterFlags);
    }
}
