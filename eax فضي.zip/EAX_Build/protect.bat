@echo off
setlocal
cd /d "%~dp0"
echo === Protecting EAX (code obfuscation) ===
echo.
if not exist "EAX_App\EAX.dll" goto nobuild
where dotnet >nul 2>nul
if errorlevel 1 goto nodotnet

set "NETCORE="
for /d %%D in ("%ProgramFiles%\dotnet\shared\Microsoft.NETCore.App\9.*") do set "NETCORE=%%~fD"
set "DESKTOP="
for /d %%D in ("%ProgramFiles%\dotnet\shared\Microsoft.WindowsDesktop.App\9.*") do set "DESKTOP=%%~fD"
if not defined NETCORE goto noruntime
if not defined DESKTOP goto noruntime

echo Installing the free Obfuscar tool (needs internet the first time)...
dotnet tool install --global Obfuscar.GlobalTool >nul 2>nul
dotnet tool update --global Obfuscar.GlobalTool >nul 2>nul
set "OBF=%USERPROFILE%\.dotnet\tools\obfuscar.console.exe"
if not exist "%OBF%" goto notool

if exist "ObfOut" rmdir /s /q "ObfOut"
mkdir "ObfOut"
if exist "EAX_Protected" rmdir /s /q "EAX_Protected"
xcopy /e /i /y "EAX_App" "EAX_Protected" >nul

powershell -NoProfile -Command "(Get-Content 'obfuscar.template.xml' -Raw).Replace('@IN@',(Resolve-Path 'EAX_App').Path).Replace('@OUT@',((Resolve-Path '.').Path + '\ObfOut')).Replace('@NETCORE@',$env:NETCORE).Replace('@DESKTOP@',$env:DESKTOP) | Set-Content 'obfuscar.xml' -Encoding UTF8"

"%OBF%" obfuscar.xml
if errorlevel 1 goto failed
if not exist "ObfOut\EAX.dll" goto failed

copy /y "ObfOut\EAX.dll" "EAX_Protected\EAX.dll" >nul
del /q "EAX_Protected\*.pdb" 2>nul
rmdir /s /q "ObfOut"
del /q "obfuscar.xml" 2>nul

echo.
echo Done. Protected copy: EAX_Protected\EAX.exe
echo TEST IT FIRST. If anything misbehaves, share EAX_App instead.
start "" "%~dp0EAX_Protected\EAX.exe"
pause
exit /b 0

:nobuild
echo Run build.bat first (EAX_App\EAX.dll was not found).
pause
exit /b 1
:nodotnet
echo .NET SDK not found.
pause
exit /b 1
:noruntime
echo Could not find the .NET 9 runtime folders under %ProgramFiles%\dotnet\shared.
pause
exit /b 1
:notool
echo Could not install the Obfuscar tool. Check your internet connection and run this again.
pause
exit /b 1
:failed
echo Protection failed. Your normal build in EAX_App is untouched and still works.
pause
exit /b 1
