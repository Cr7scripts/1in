@echo off
setlocal
cd /d "%~dp0"
set "SRC=EAX_Protected"
if not exist "%SRC%\EAX.exe" set "SRC=EAX_App"
if not exist "%SRC%\EAX.exe" goto missing
del /q "%SRC%\*.pdb" 2>nul
del /q "EAX_Release.zip" 2>nul
powershell -NoProfile -Command "Compress-Archive -Path '%SRC%\*' -DestinationPath 'EAX_Release.zip' -Force"
echo.
echo Created EAX_Release.zip from %SRC%
echo It contains only the program - NO source code. Share this file, never the source folder.
pause
exit /b 0
:missing
echo Run build.bat first.
pause
exit /b 1
