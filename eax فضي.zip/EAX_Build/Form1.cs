using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Text;

namespace EAX;

internal static class AudioBackend
{
    [DllImport("eax_audio.dll", CallingConvention = CallingConvention.Cdecl)] internal static extern int eax_device_count(int kind);
    [DllImport("eax_audio.dll", CallingConvention = CallingConvention.Cdecl)] internal static extern nuint eax_device_name(int kind, int index, StringBuilder buffer, nuint capacity);
    [DllImport("eax_audio.dll", CallingConvention = CallingConvention.Cdecl)] internal static extern int eax_start(int inputIndex, int outputIndex);
    [DllImport("eax_audio.dll", CallingConvention = CallingConvention.Cdecl)] internal static extern void eax_stop();
    [DllImport("eax_audio.dll", CallingConvention = CallingConvention.Cdecl)] internal static extern void eax_set_preset(int index);
    [DllImport("eax_audio.dll", CallingConvention = CallingConvention.Cdecl)] internal static extern void eax_set_amount(int amount);
    [DllImport("eax_audio.dll", CallingConvention = CallingConvention.Cdecl)] internal static extern nuint eax_last_error(StringBuilder buffer, nuint capacity);

    internal static List<string> Devices(int kind)
    {
        int count = Math.Max(0, eax_device_count(kind));
        var names = new List<string>(count);
        for (int i = 0; i < count; i++)
        {
            var text = new StringBuilder(512);
            eax_device_name(kind, i, text, (nuint)text.Capacity);
            names.Add(text.ToString());
        }
        return names;
    }

    internal static string LastError()
    {
        var text = new StringBuilder(1024);
        eax_last_error(text, (nuint)text.Capacity);
        return text.ToString();
    }
}

internal static class NativeWindowDrag
{
    private const int WmNcLButtonDown = 0x00A1;
    private const int HtCaption = 0x0002;

    [DllImport("user32.dll")] private static extern bool ReleaseCapture();
    [DllImport("user32.dll")] private static extern nint SendMessage(nint hWnd, int msg, nint wParam, nint lParam);

    internal static void Begin(Form form)
    {
        ReleaseCapture();
        SendMessage(form.Handle, WmNcLButtonDown, (nint)HtCaption, 0);
    }
}

internal static class NativeTheme
{
    [DllImport("uxtheme.dll", CharSet = CharSet.Unicode)]
    private static extern int SetWindowTheme(nint hWnd, string? appName, string? idList);
    internal static void Dark(Control control)
    {
        try { SetWindowTheme(control.Handle, "DarkMode_Explorer", null); } catch { }
    }
}

internal static class NativeCursor
{
    [StructLayout(LayoutKind.Sequential)]
    private struct IconInfo { public bool fIcon; public int xHotspot, yHotspot; public nint hbmMask, hbmColor; }

    [DllImport("user32.dll")] private static extern bool GetIconInfo(nint hIcon, out IconInfo info);
    [DllImport("user32.dll")] private static extern nint CreateIconIndirect(ref IconInfo info);
    [DllImport("user32.dll")] private static extern bool DestroyIcon(nint hIcon);
    [DllImport("gdi32.dll")] private static extern bool DeleteObject(nint handle);

    /// <summary>Builds a real Windows cursor from SOON.png (the blue pointing hand). Falls back to the standard hand.</summary>
    internal static Cursor FromImage(string path, int width, int height, int hotX, int hotY)
    {
        try
        {
            if (!File.Exists(path)) return Cursors.Hand;
            using var source = new Bitmap(path);
            using var small = new Bitmap(width, height, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(small))
            {
                g.Clear(Color.Transparent);
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.DrawImage(source, new Rectangle(0, 0, width, height));
            }
            nint icon = small.GetHicon();
            if (!GetIconInfo(icon, out IconInfo info)) { DestroyIcon(icon); return Cursors.Hand; }
            info.fIcon = false; info.xHotspot = hotX; info.yHotspot = hotY;
            nint handle = CreateIconIndirect(ref info);
            DeleteObject(info.hbmMask); DeleteObject(info.hbmColor); DestroyIcon(icon);
            return handle != 0 ? new Cursor(handle) : Cursors.Hand;
        }
        catch { return Cursors.Hand; }
    }
}

/// <summary>One shared connection to Voicemeeter's Remote API, kept open while the app runs.</summary>
internal static class VoicemeeterRemote
{
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] private delegate int LoginCall();
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] private delegate int LogoutCall();
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] private delegate int DirtyCall();
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] private delegate int GetFloatCall([MarshalAs(UnmanagedType.LPStr)] string name, out float value);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] private delegate int SetFloatCall([MarshalAs(UnmanagedType.LPStr)] string name, float value);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] private delegate int GetTypeCall(out int type);

    private static nint _library;
    private static LogoutCall? _logout;
    private static DirtyCall? _dirty;
    private static GetFloatCall? _get;
    private static SetFloatCall? _set;

    internal static bool Connected { get; private set; }
    /// <summary>1 = Standard, 2 = Banana, 3 = Potato.</summary>
    internal static int Edition { get; private set; }
    /// <summary>Index of the "Voicemeeter Input" (VAIO) strip, which is where this app plays its sound.</summary>
    internal static int VaioStrip => Edition switch { 1 => 2, 2 => 3, 3 => 5, _ => -1 };

    /// <summary>Returns null when connected, otherwise a message that explains what to fix.</summary>
    internal static string? Connect()
    {
        if (Connected) return null;
        string dll = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "VB", "Voicemeeter", "VoicemeeterRemote64.dll");
        if (!File.Exists(dll)) return "Voicemeeter Remote API was not found. Install or repair Voicemeeter.";
        try
        {
            _library = NativeLibrary.Load(dll);
            var login = Marshal.GetDelegateForFunctionPointer<LoginCall>(NativeLibrary.GetExport(_library, "VBVMR_Login"));
            _logout = Marshal.GetDelegateForFunctionPointer<LogoutCall>(NativeLibrary.GetExport(_library, "VBVMR_Logout"));
            _dirty = Marshal.GetDelegateForFunctionPointer<DirtyCall>(NativeLibrary.GetExport(_library, "VBVMR_IsParametersDirty"));
            _get = Marshal.GetDelegateForFunctionPointer<GetFloatCall>(NativeLibrary.GetExport(_library, "VBVMR_GetParameterFloat"));
            _set = Marshal.GetDelegateForFunctionPointer<SetFloatCall>(NativeLibrary.GetExport(_library, "VBVMR_SetParameterFloat"));
            var getType = Marshal.GetDelegateForFunctionPointer<GetTypeCall>(NativeLibrary.GetExport(_library, "VBVMR_GetVoicemeeterType"));
            if (login() != 0) { Release(); return "Open Voicemeeter first, then try again."; }
            if (getType(out int type) != 0 || type < 1 || type > 3) { _logout(); Release(); return "Could not detect the Voicemeeter edition."; }
            Edition = type;
            Connected = true;
            return null;
        }
        catch (Exception ex)
        {
            Release();
            return "Voicemeeter connection failed: " + ex.Message;
        }
    }

    internal static bool Set(string name, float value) => Connected && _set!(name, value) == 0;

    internal static bool Get(string name, out float value)
    {
        value = 0;
        if (!Connected) return false;
        _dirty?.Invoke();   // refresh the cached parameters before reading
        return _get!(name, out value) == 0;
    }

    internal static void Disconnect()
    {
        if (Connected) { try { _logout?.Invoke(); } catch { } }
        Connected = false;
        Release();
    }

    private static void Release()
    {
        if (_library != 0) { try { NativeLibrary.Free(_library); } catch { } }
        _library = 0; _logout = null; _dirty = null; _get = null; _set = null;
    }
}

/// <summary>Routes the app's output to Voicemeeter Out B1 (the Discord microphone) and controls the "hear myself" monitor.</summary>
internal sealed class VoicemeeterAppMicRoute : IDisposable
{
    private string _b1Route = "", _a1Route = "";
    private bool _routeWasChanged, _a1WasChanged;
    private float _previousB1, _previousA1;

    internal void EnableForOutput(string outputName, bool hearMyself)
    {
        if (!outputName.Contains("Voicemeeter Input", StringComparison.OrdinalIgnoreCase)) return;
        string? error = VoicemeeterRemote.Connect();
        if (error is not null) throw new InvalidOperationException(error);
        int strip = VoicemeeterRemote.VaioStrip;
        if (strip < 0) throw new InvalidOperationException("Unknown Voicemeeter edition.");
        _b1Route = $"Strip[{strip}].B1";
        _a1Route = $"Strip[{strip}].A1";
        try
        {
            if (!VoicemeeterRemote.Get(_b1Route, out _previousB1)) throw new InvalidOperationException("Could not read Voicemeeter's B1 routing state.");
            if (_previousB1 < 0.5f)
            {
                if (!VoicemeeterRemote.Set(_b1Route, 1.0f)) throw new InvalidOperationException("Could not route the processed microphone to Voicemeeter Out B1.");
                _routeWasChanged = true;
            }
            // A1 = the person's own headphones. On = hear yourself, off = only the Discord side gets the voice.
            if (VoicemeeterRemote.Get(_a1Route, out _previousA1))
            {
                float wanted = hearMyself ? 1.0f : 0.0f;
                if (Math.Abs(_previousA1 - wanted) > 0.5f && VoicemeeterRemote.Set(_a1Route, wanted)) _a1WasChanged = true;
            }
        }
        catch
        {
            Disable();
            throw;
        }
    }

    internal void Disable()
    {
        if (_a1WasChanged) VoicemeeterRemote.Set(_a1Route, _previousA1);
        _a1WasChanged = false;
        if (_routeWasChanged) VoicemeeterRemote.Set(_b1Route, _previousB1);
        _routeWasChanged = false;
    }

    public void Dispose() => Disable();
}

public sealed class MainForm : Form
{
    private const int WinW = 560, WinH = 368;

    // The dark theme artwork was cut out of the original sheet (window starts at 712,668 and is 1230 px wide).
    // Art() converts a rectangle measured on that sheet into form coordinates, so every control lines up with the art.
    private const double ArtScale = 560.0 / 1230.0;
    private static Rectangle Art(int x0, int y0, int x1, int y1) =>
        Rectangle.FromLTRB((int)Math.Round((x0 - 712) * ArtScale), (int)Math.Round((y0 - 668) * ArtScale),
                           (int)Math.Round((x1 - 712) * ArtScale), (int)Math.Round((y1 - 668) * ArtScale));
    private static readonly Rectangle Track = Art(1616, 1086, 1834, 1094);
    private static readonly string[] Presets =
    [
        "Auditorium", "Ball Park", "Bathroom", "Cathedral", "Chapel", "Church",
        "Concert Hall", "Garage", "Haunted Cavern", "Indoor Arena", "Jazz Club",
        "Living Room", "Opera House", "Small Room", "Theater"
    ];

    private readonly string _assets;
    private readonly PictureBox _enable = new();
    private readonly PictureBox _thumb = new();
    // Text is painted directly on the form (no transparent Labels) so it can never ghost or stack on top of itself.
    // The background artwork already has "Haunted Cavern" and "SB Digital Music LX" baked into it. Those two spots are
    // already erased from the new dark background image, so only our live text is drawn there.
    private static readonly Rectangle PresetRect = Art(1148, 1070, 1400, 1098);
    private static readonly Rectangle DeviceRect = Art(1226, 699, 1576, 724);
    private const string Credit = "made by 3ah";
    private static readonly Rectangle CreditRect = Art(1600, 1350, 1895, 1376);
    private static readonly Color TextColor = Color.FromArgb(214, 214, 218);
    private readonly Font _textFont = new("Segoe UI", 8f);
    private string _presetText = "", _deviceText = "";
    private PictureBox _deviceButton = null!, _sliderHit = null!;
    private Cursor _hand = Cursors.Hand;

    internal sealed class UserSettings
    {
        public bool EqEnabled { get; set; }
        public int[] EqGains { get; set; } = new int[10];     // tenths of a dB per band
        public int[] EqCustom { get; set; } = new int[10];
        public string EqPreset { get; set; } = "EQ Flat";
        public bool BassEnabled { get; set; }
        public int BassLevel { get; set; } = 50;
        public int BassCutoff { get; set; } = 100;
        public string? Input { get; set; }
        public string? Output { get; set; }
        public int Preset { get; set; } = 8;
        public int Amount { get; set; } = 100;
        public bool HearMyself { get; set; } = true;
    }
    private static readonly string SettingsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "EAX", "settings.json");
    private readonly UserSettings _settings = LoadSettings();

    private static UserSettings LoadSettings()
    {
        try
        {
            string oldPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FakeEAX", "settings.json");
            string path = File.Exists(SettingsPath) ? SettingsPath : oldPath;
            if (File.Exists(path)) return System.Text.Json.JsonSerializer.Deserialize<UserSettings>(File.ReadAllText(path)) ?? new();
        }
        catch { }
        return new();
    }

    private void SaveSettings()
    {
        try
        {
            if (_inputIndex >= 0 && _inputIndex < _inputs.Count) _settings.Input = _inputs[_inputIndex];
            if (_outputIndex >= 0 && _outputIndex < _outputs.Count) _settings.Output = _outputs[_outputIndex];
            _settings.Preset = _presetIndex;
            _settings.Amount = _amount;
            Directory.CreateDirectory(Path.GetDirectoryName(SettingsPath)!);
            File.WriteAllText(SettingsPath, System.Text.Json.JsonSerializer.Serialize(_settings));
        }
        catch { }
    }

    private static int SavedOrPreferred(List<string> devices, string? saved, int fallback)
    {
        int index = saved is null ? -1 : devices.FindIndex(name => name == saved);
        return index >= 0 ? index : fallback;
    }
    private readonly ListBox _presets = new();
    private readonly ToolTip _deviceTip = new();
    private readonly VoicemeeterAppMicRoute _appMicRoute = new();
    private readonly Image _enableOn, _enableOff, _thumbImage, _closeImage, _minImage;
    private List<string> _inputs = [], _outputs = [];
    private int _amount, _inputIndex, _outputIndex = -1;
    private bool _enabled, _dragging, _closing;
    private readonly System.Windows.Forms.Timer _amountAnim = new() { Interval = 15 };
    private int _amountTarget;
    private int _presetIndex = 8;

    public MainForm()
    {
        Opacity = 0;   // faded in from OnShown
        Text = "EAX Settings";
        AutoScaleMode = AutoScaleMode.None;
        ClientSize = new Size(WinW, WinH);
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.CenterScreen;
        DoubleBuffered = true;
        _assets = Path.Combine(AppContext.BaseDirectory, "Assets");
        _presetIndex = Math.Clamp(_settings.Preset, 0, Presets.Length - 1);
        _amount = Math.Clamp(_settings.Amount, 0, 100);   // default 100 (the engine's maximum) so the reverb is strong right away
        _hand = NativeCursor.FromImage(Path.Combine(_assets, "SOON.png"), 24, 33, 8, 1);
        using (var raw = new Bitmap(Path.Combine(_assets, "EAX_Background.png")))
        {
            var clean = new Bitmap(raw.Width, raw.Height, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(clean))
            {
                g.DrawImage(raw, 0, 0, raw.Width, raw.Height);
            }
            BackgroundImage = clean;
        }
        BackgroundImageLayout = ImageLayout.Stretch;
        ApplyBackgroundRegion(Path.Combine(_assets, "EAX_Background.png"));
        string icon = Path.Combine(_assets, "AppIcon.ico");
        if (File.Exists(icon)) Icon = new Icon(icon);

        _enableOn = Image.FromFile(Path.Combine(_assets, "EAX_Bttn_Checkbox.png"));
        _enableOff = Image.FromFile(Path.Combine(_assets, "EAX_Bttn_Checkbox2.png"));
        _thumbImage = Image.FromFile(Path.Combine(_assets, "SliderThumb.png"));
        _closeImage = Image.FromFile(Path.Combine(_assets, "Share_Bttn_GradMnu32_Close.PNG"));
        _minImage = Image.FromFile(Path.Combine(_assets, "Share_Bttn_GradMnu32_Minimise.png"));

        BuildControls();
        ToneBackend.ApplyAll(_settings);   // restore equalizer / bass boost (needs the newer eax_audio.dll)
        FormClosing += (_, e) =>
        {
            // Smooth fade-out when the user closes the window (not when Windows is shutting down).
            if (!_closing && e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true; _closing = true;
                int step = 0;
                var fade = new System.Windows.Forms.Timer { Interval = 15 };
                fade.Tick += (_, _) =>
                {
                    step++; Opacity = Math.Max(0, 1 - step / 10.0);
                    if (step >= 10) { fade.Stop(); fade.Dispose(); Close(); }
                };
                fade.Start();
                return;
            }
            SaveSettings(); StopAudio(); _appMicRoute.Dispose(); ToneBackend.Shutdown();
        };
        MouseDown += (_, e) => { if (e.Button == MouseButtons.Left) NativeWindowDrag.Begin(this); };
    }

    private BassBoostForm? _bassWindow;
    private EqualizerForm? _eqWindow;
    private string MicName => _inputIndex >= 0 && _inputIndex < _inputs.Count ? _inputs[_inputIndex] : "";

    private void OpenBass()
    {
        if (_bassWindow is { IsDisposed: false }) { _bassWindow.WindowState = FormWindowState.Normal; _bassWindow.Activate(); return; }
        _bassWindow = new BassBoostForm(_assets, _hand, _settings, SaveSettings, MicName);
        _bassWindow.FormClosed += (_, _) => _bassWindow = null;
        _bassWindow.Show(this);
    }

    private void OpenEqualizer()
    {
        if (_eqWindow is { IsDisposed: false }) { _eqWindow.WindowState = FormWindowState.Normal; _eqWindow.Activate(); return; }
        _eqWindow = new EqualizerForm(_assets, _hand, _settings, SaveSettings, MicName);
        _eqWindow.FormClosed += (_, _) => _eqWindow = null;
        _eqWindow.Show(this);
    }

    protected override void OnShown(EventArgs e)
    {
        base.OnShown(e);
        int step = 0;
        var fade = new System.Windows.Forms.Timer { Interval = 15 };
        fade.Tick += (_, _) =>
        {
            step++; Opacity = Math.Min(1.0, step / 14.0);
            if (step >= 14) { fade.Stop(); fade.Dispose(); }
        };
        fade.Start();
    }

    /// <summary>Applies the device lists that were scanned in the background while the loading screen was showing.</summary>
    internal void LoadDevices(DeviceSnapshot? snapshot)
    {
        if (snapshot is null) { SetText(ref _deviceText, "Audio backend missing", DeviceRect); return; }
        ApplyDevices(snapshot);
    }

    private void BuildControls()
    {
        _enable.Bounds = Art(748, 944, 790, 986);
        _enable.Image = _enableOff;
        _enable.SizeMode = PictureBoxSizeMode.Zoom;
        _enable.BackColor = Color.Transparent;
        _enable.Cursor = _hand;
        _enable.Click += (_, _) => ToggleEffects();
        Controls.Add(_enable);

        var enableText = new PictureBox { Bounds = Art(795, 946, 1045, 984), BackColor = Color.Transparent, Cursor = _hand };
        enableText.Click += (_, _) => ToggleEffects();
        Controls.Add(enableText);

        var listBounds = Art(1148, 1112, 1565, 1348); listBounds.Inflate(-1, -1);   // keep the art's own 1px border visible
        _presets.Bounds = listBounds;
        _presets.Font = new Font("Segoe UI", 8f);
        _presets.BorderStyle = BorderStyle.None;
        _presets.BackColor = Color.FromArgb(1, 1, 1);
        _presets.ForeColor = TextColor;
        _presets.DrawMode = DrawMode.OwnerDrawFixed;
        _presets.ItemHeight = 17;
        _presets.IntegralHeight = false;
        _presets.DrawItem += (_, e) =>
        {
            if (e.Index < 0) return;
            bool selected = (e.State & DrawItemState.Selected) != 0;
            Color back = selected ? Color.FromArgb(52, 53, 57) : (e.Index % 2 == 0 ? Color.FromArgb(1, 1, 1) : Color.FromArgb(22, 22, 22));
            using (var brush = new SolidBrush(back)) e.Graphics.FillRectangle(brush, e.Bounds);
            TextRenderer.DrawText(e.Graphics, Presets[e.Index], _presets.Font,
                new Rectangle(e.Bounds.X + 4, e.Bounds.Y, e.Bounds.Width - 4, e.Bounds.Height), TextColor,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine | TextFormatFlags.NoPrefix);
        };
        _presets.HandleCreated += (_, _) => NativeTheme.Dark(_presets);   // dark scrollbar
        _presets.Items.AddRange(Presets.Cast<object>().ToArray());
        _presets.SelectedIndex = _presetIndex;
        _presets.SelectedIndexChanged += (_, _) =>
        {
            if (_presets.SelectedIndex < 0) return;
            _presetIndex = _presets.SelectedIndex;
            SetText(ref _presetText, Presets[_presetIndex], PresetRect);
            AudioBackend.eax_set_preset(_presetIndex);
        };
        Controls.Add(_presets);

        _presetText = Presets[_presetIndex];

        _thumb.SetBounds(0, 0, 20, 14);
        _thumb.Image = _thumbImage;
        _thumb.SizeMode = PictureBoxSizeMode.Zoom;
        _thumb.BackColor = Color.Transparent;
        _thumb.Cursor = _hand;
        _sliderHit = new PictureBox { Bounds = Art(1598, 1062, 1852, 1118), BackColor = Color.Transparent, Cursor = _hand };
        foreach (var slider in new[] { _thumb, _sliderHit })
        {
            slider.MouseDown += (sender, e) =>
            {
                if (e.Button != MouseButtons.Left) return;
                _dragging = true;
                if (ReferenceEquals(sender, _sliderHit)) AnimateAmountTo(AmountAtCursor());   // click on the groove glides there
                else _amountAnim.Stop();
            };
            slider.MouseMove += (_, _) => { if (_dragging) { _amountAnim.Stop(); ApplyAmount(AmountAtCursor()); } };
            slider.MouseUp += (_, _) => _dragging = false;
        }
        _amountAnim.Tick += (_, _) =>
        {
            int diff = _amountTarget - _amount;
            if (diff == 0) { _amountAnim.Stop(); return; }
            int step = Math.Sign(diff) * Math.Max(1, (int)Math.Ceiling(Math.Abs(diff) * 0.3));
            ApplyAmount(_amount + step);
        };
        Controls.Add(_thumb);
        Controls.Add(_sliderHit);
        PositionThumb();
        UpdateAmountTip();

        _deviceButton = new PictureBox { Bounds = Art(1190, 684, 1624, 736), BackColor = Color.Transparent, Cursor = _hand };
        _deviceButton.Click += (_, _) => OpenDevicePicker();
        Controls.Add(_deviceButton);

        // The "?" button shows who made the app.
        var helpButton = new PictureBox { Bounds = Art(1628, 684, 1712, 736), BackColor = Color.Transparent, Cursor = _hand };
        helpButton.Click += (_, _) => MessageBox.Show(this, "EAX Effects\n\nMade by 3ah\n\n\u00A9 3ah. All rights reserved.", "About", MessageBoxButtons.OK, MessageBoxIcon.Information);
        _deviceTip.SetToolTip(helpButton, "About - " + Credit);
        Controls.Add(helpButton);

        // Bottom-bar icons: "III" opens Bass Boost, the grid icon opens the Equalizer.
        var bassIcon = new PictureBox { Bounds = Art(1003, 1412, 1051, 1458), BackColor = Color.Transparent, Cursor = _hand };
        bassIcon.Click += (_, _) => OpenBass();
        _deviceTip.SetToolTip(bassIcon, "Bass Boost");
        Controls.Add(bassIcon);
        var eqIcon = new PictureBox { Bounds = Art(1239, 1412, 1288, 1458), BackColor = Color.Transparent, Cursor = _hand };
        eqIcon.Click += (_, _) => OpenEqualizer();
        _deviceTip.SetToolTip(eqIcon, "Equalizer");
        Controls.Add(eqIcon);

        // The blue arrow next to the field opens the same audio settings (microphone + output).
        var settingsArrow = new PictureBox { Bounds = Art(1716, 684, 1756, 736), BackColor = Color.Transparent, Cursor = _hand };
        settingsArrow.Click += (_, _) => OpenDevicePicker();
        _deviceTip.SetToolTip(settingsArrow, "Audio settings: choose microphone and output");
        Controls.Add(settingsArrow);

        AddTitleButton(Art(1846, 690, 1888, 732), _closeImage, (_, _) => Close());
        AddTitleButton(Art(1792, 690, 1834, 732), _minImage, (_, _) => WindowState = FormWindowState.Minimized);
    }

    private void AddTitleButton(Rectangle bounds, Image image, EventHandler click)
    {
        var button = new PictureBox { Bounds = bounds, Image = image, SizeMode = PictureBoxSizeMode.Zoom, BackColor = Color.Transparent, Cursor = _hand };
        button.Click += click;
        Controls.Add(button);
        button.BringToFront();
    }

    private void ApplyDevices(DeviceSnapshot snapshot)
    {
        bool firstLoad = _inputs.Count == 0 && _outputs.Count == 0;
        _inputs = snapshot.Inputs;
        _outputs = snapshot.Outputs;
        if (_inputs.Count == 0) _inputIndex = -1;
        else if (firstLoad) _inputIndex = SavedOrPreferred(_inputs, _settings.Input, PreferredInput(_inputs));
        else _inputIndex = Math.Clamp(_inputIndex < 0 ? 0 : _inputIndex, 0, _inputs.Count - 1);
        if (_outputs.Count == 0) _outputIndex = -1;
        else if (firstLoad) _outputIndex = SavedOrPreferred(_outputs, _settings.Output, PreferredOutput(_outputs));
        else _outputIndex = Math.Clamp(_outputIndex < 0 ? 0 : _outputIndex, 0, _outputs.Count - 1);
        UpdateDeviceLabel();
    }

    // Capture devices that are really outputs of Voicemeeter / VB-Cable. Using one as the microphone feeds the effect
    // back into itself (the loud hum) and the real voice never reaches the effect.
    private static bool IsVirtualInput(string name) =>
        name.Contains("Voicemeeter Out", StringComparison.OrdinalIgnoreCase)
        || name.Contains("Voicemeeter Aux Out", StringComparison.OrdinalIgnoreCase)
        || name.Contains("CABLE Output", StringComparison.OrdinalIgnoreCase);

    // A real loop only exists when the processed sound lands back in the very source we are listening to.
    private static bool WouldFeedBack(string source, string output)
    {
        bool sourceIsB1 = source.Contains("Voicemeeter Out B1", StringComparison.OrdinalIgnoreCase);
        bool sourceIsCable = source.Contains("CABLE Output", StringComparison.OrdinalIgnoreCase);
        bool outputIsVaio = output.Contains("Voicemeeter Input", StringComparison.OrdinalIgnoreCase);
        bool outputIsCable = output.Contains("CABLE Input", StringComparison.OrdinalIgnoreCase);
        return (sourceIsB1 && outputIsVaio) || (sourceIsCable && outputIsCable);
    }

    private static int PreferredInput(List<string> devices)
    {
        int preferred = devices.FindIndex(name => name.Contains("Headset Microphone", StringComparison.OrdinalIgnoreCase));
        if (preferred >= 0) return preferred;
        preferred = devices.FindIndex(name => !IsVirtualInput(name));
        return preferred >= 0 ? preferred : 0;
    }

    private static int PreferredOutput(List<string> devices)
    {
        int preferred = devices.FindIndex(name => name.Contains("Voicemeeter Input", StringComparison.OrdinalIgnoreCase));
        if (preferred < 0) preferred = devices.FindIndex(name => name.Contains("CABLE Input", StringComparison.OrdinalIgnoreCase));
        return preferred >= 0 ? preferred : 0;
    }

    private void UpdateDeviceLabel()
    {
        SetText(ref _deviceText, _inputIndex >= 0 ? _inputs[_inputIndex] : "Select microphone", DeviceRect);
        string output = _outputIndex >= 0 ? _outputs[_outputIndex] : "(none)";
        string tip = $"Microphone: {(_inputIndex >= 0 ? _inputs[_inputIndex] : "(none)")}\nOutput: {output}\n" +
            (output.Contains("Voicemeeter Input", StringComparison.OrdinalIgnoreCase)
                ? "In Discord / apps choose the microphone: Voicemeeter Out B1."
                : output.Contains("CABLE Input", StringComparison.OrdinalIgnoreCase)
                    ? "In Discord / apps choose the microphone: CABLE Output."
                    : "Choose CABLE Input (or Voicemeeter Input) as output to send the processed mic to Discord.") +
            "\nClick to change.";
        _deviceTip.SetToolTip(_deviceButton, tip);
    }

    private void OpenDevicePicker()
    {
        // The dialog opens instantly with the lists we already have; a fresh scan runs in the background and updates it.
        using var picker = new AudioSettingsForm(_assets, _hand, _inputs, _outputs, _inputIndex, _outputIndex, _settings.HearMyself);
        DeviceCache.Refresh().ContinueWith(task =>
        {
            if (task.IsCompletedSuccessfully) picker.OfferDevices(task.Result.Inputs, task.Result.Outputs);
        });
        if (picker.ShowDialog(this) != DialogResult.OK) return;
        _inputs = picker.Inputs;
        _outputs = picker.Outputs;
        _inputIndex = picker.InputIndex;
        _outputIndex = picker.OutputIndex;
        _settings.HearMyself = picker.HearMyself;
        UpdateDeviceLabel();
        SaveSettings();
        if (_enabled) StartAudio();
    }

    private void ToggleEffects()
    {
        if (_enabled)
        {
            _enabled = false;
            StopAudio();
            _enable.Image = _enableOff;
            return;
        }
        _enabled = true;
        _enable.Image = _enableOn;
       
        StartAudio();
    }

    private void StartAudio()
    {
        AudioBackend.eax_stop();
        _appMicRoute.Disable();
        if (_inputIndex < 0 || _outputIndex < 0)
        {
            _enabled = false; _enable.Image = _enableOff;
            MessageBox.Show(this, "Choose a microphone and headphones/output first.", "EAX Settings", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        if (_outputIndex >= 0 && WouldFeedBack(_inputs[_inputIndex], _outputs[_outputIndex]))
        {
            _enabled = false; _enable.Image = _enableOff;
            MessageBox.Show(this,
                "The sound source is:\n" + _inputs[_inputIndex] + "\nand the output is:\n" + _outputs[_outputIndex] +
                "\n\nThe processed sound would go straight back into its own source (that is the hum).\n" +
                "Choose a different output, or another source (see the clip notes in BUILD_DLL.txt).\n\n" +
                "الصوت المعالج بيرجع لنفس المصدر وهذا اللي يسبب الطنين. غيّر الإخراج أو المصدر.",
                "EAX Settings", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        AudioBackend.eax_set_preset(_presetIndex);
        AudioBackend.eax_set_amount(_amount);
        try
        {
            _appMicRoute.EnableForOutput(_outputs[_outputIndex], _settings.HearMyself);
        }
        catch (Exception e)
        {
            _enabled = false; _enable.Image = _enableOff;
            MessageBox.Show(this, e.Message, "Voicemeeter Routing", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        if (AudioBackend.eax_start(_inputIndex, _outputIndex) != 0)
        {
            string message = AudioBackend.LastError();
            _appMicRoute.Disable();
            _enabled = false; _enable.Image = _enableOff;
            MessageBox.Show(this, message, "Audio Device", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void StopAudio()
    {
        AudioBackend.eax_stop();
        _appMicRoute.Disable();
    }

    private int AmountAtCursor()
    {
        int usableLeft = Track.Left + _thumb.Width / 2;
        int usableRight = Track.Right - _thumb.Width / 2;
        int center = Math.Clamp(PointToClient(Cursor.Position).X, usableLeft, usableRight);
        return (int)Math.Round((center - usableLeft) / (float)(usableRight - usableLeft) * 100);
    }

    private void ApplyAmount(int value)
    {
        value = Math.Clamp(value, 0, 100);
        if (value == _amount) return;
        _amount = value;
        PositionThumb();
        UpdateAmountTip();
        AudioBackend.eax_set_amount(_amount);
    }

    private void AnimateAmountTo(int target)
    {
        _amountTarget = Math.Clamp(target, 0, 100);
        _amountAnim.Start();
    }

    private void UpdateAmountTip()
    {
        string tip = $"Effects Amount: {_amount}";
        _deviceTip.SetToolTip(_thumb, tip);
        _deviceTip.SetToolTip(_sliderHit, tip);
    }

    private void SetText(ref string field, string value, Rectangle area)
    {
        if (field == value) return;
        field = value;
        Invalidate(Rectangle.Inflate(area, 2, 2));
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        const TextFormatFlags flags = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine
            | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding;
        TextRenderer.DrawText(e.Graphics, _presetText, _textFont, PresetRect, TextColor, flags);
        TextRenderer.DrawText(e.Graphics, _deviceText, _textFont, DeviceRect, TextColor, flags);
        TextRenderer.DrawText(e.Graphics, Credit, _textFont, CreditRect, Color.FromArgb(104, 107, 114),
            TextFormatFlags.Right | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine | TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding);
    }

    private void PositionThumb()
    {
        int usableLeft = Track.Left + _thumb.Width / 2;
        int usableRight = Track.Right - _thumb.Width / 2;
        int center = usableLeft + (int)(_amount / 100f * (usableRight - usableLeft));
        _thumb.Location = new Point(center - _thumb.Width / 2, Track.Top + Track.Height / 2 - _thumb.Height / 2);
        _thumb.BringToFront();
    }

    private void ApplyBackgroundRegion(string imagePath)
    {
        using var original = new Bitmap(imagePath);
        using var scaled = new Bitmap(original, new Size(WinW, WinH));
        Region = RegionFromBitmap(scaled);
    }

    internal static Region RegionFromBitmap(Bitmap scaled)
    {
        var region = new Region(Rectangle.Empty);
        var bounds = new Rectangle(0, 0, scaled.Width, scaled.Height);
        var data = scaled.LockBits(bounds, ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        try
        {
            unsafe
            {
                byte* pixels = (byte*)data.Scan0;
                for (int y = 0; y < scaled.Height; y++)
                {
                    byte* row = pixels + y * data.Stride;
                    int start = -1;
                    for (int x = 0; x < scaled.Width; x++)
                    {
                        bool visible = row[x * 4 + 3] >= 10;
                        if (visible && start < 0) start = x;
                        if (!visible && start >= 0) { region.Union(new Rectangle(start, y, x - start, 1)); start = -1; }
                    }
                    if (start >= 0) region.Union(new Rectangle(start, y, scaled.Width - start, 1));
                }
            }
        }
        finally { scaled.UnlockBits(data); }
        return region;
    }
}

internal sealed record DeviceSnapshot(List<string> Inputs, List<string> Outputs);

/// <summary>Scans audio devices off the UI thread. Scanning is slow (it opens every device), so it must never block a click.</summary>
internal static class DeviceCache
{
    internal static DeviceSnapshot? Latest { get; private set; }

    internal static Task<DeviceSnapshot> Refresh() => Task.Run(() =>
    {
        var snapshot = new DeviceSnapshot(AudioBackend.Devices(0), AudioBackend.Devices(1));
        Latest = snapshot;
        return snapshot;
    });
}

/// <summary>Dark "Audio Settings" window: microphone, output and the hear-myself switch.</summary>
internal sealed class AudioSettingsForm : Form
{
    // Rectangles were measured on the 1024x572 artwork; the plate was cropped at (70,40) and scaled by 0.65.
    private const double K = 0.65;
    private const int OriginX = 70, OriginY = 40;
    private static Rectangle A(int x0, int y0, int x1, int y1) =>
        Rectangle.FromLTRB((int)Math.Round((x0 - OriginX) * K), (int)Math.Round((y0 - OriginY) * K),
                           (int)Math.Round((x1 - OriginX) * K), (int)Math.Round((y1 - OriginY) * K));

    private static readonly Rectangle MicField = A(223, 174, 772, 234);
    private static readonly Rectangle OutField = A(223, 280, 772, 340);
    private static readonly Rectangle MicText = A(252, 192, 712, 220);
    private static readonly Rectangle OutText = A(252, 298, 712, 326);
    private static readonly Rectangle CheckBoxRect = A(222, 357, 265, 399);
    private static readonly Rectangle CheckHit = A(222, 357, 650, 399);
    private static readonly Rectangle CancelBtn = A(269, 422, 489, 497);
    private static readonly Rectangle OkBtn = A(536, 422, 756, 497);

    private static readonly Color TextColor = Color.FromArgb(214, 214, 218);
    private static readonly Color HintColor = Color.FromArgb(125, 125, 130);

    private readonly Bitmap _art;
    private readonly Image _checkOn, _checkOff;
    private readonly Cursor _hand;
    private readonly Font _font = new("Segoe UI", 9f);
    private readonly float[] _glow = new float[5];        // hover glow per element, eased by a timer
    private readonly System.Windows.Forms.Timer _glowTimer = new() { Interval = 15 };
    private readonly object _lock = new();
    private (List<string> Inputs, List<string> Outputs)? _pending;
    private int _hover = -1, _pressed = -1;
    private bool _hear;

    internal List<string> Inputs { get; private set; }
    internal List<string> Outputs { get; private set; }
    internal int InputIndex { get; private set; }
    internal int OutputIndex { get; private set; }
    internal bool HearMyself => _hear;

    internal AudioSettingsForm(string assets, Cursor hand, List<string> inputs, List<string> outputs, int inputIndex, int outputIndex, bool hearMyself)
    {
        _art = new Bitmap(Path.Combine(assets, "AudioSettings.png"));
        _checkOn = Image.FromFile(Path.Combine(assets, "DlgCheckOn.png"));
        _checkOff = Image.FromFile(Path.Combine(assets, "DlgCheckOff.png"));
        _hand = hand;
        Inputs = [.. inputs]; Outputs = [.. outputs];
        InputIndex = inputIndex; OutputIndex = outputIndex; _hear = hearMyself;

        Text = "Audio Settings";
        AutoScaleMode = AutoScaleMode.None;
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.CenterParent;
        ShowInTaskbar = false;
        DoubleBuffered = true;
        KeyPreview = true;
        ClientSize = _art.Size;
        BackgroundImage = _art;
        BackgroundImageLayout = ImageLayout.Stretch;
        Region = MainForm.RegionFromBitmap(_art);
        Opacity = 0;

        _glowTimer.Tick += (_, _) =>
        {
            bool moving = false;
            for (int i = 0; i < _glow.Length; i++)
            {
                float goal = i == _hover ? 1f : 0f;
                float next = _glow[i] + (goal - _glow[i]) * 0.35f;
                if (Math.Abs(goal - next) < 0.02f) next = goal;
                if (next != _glow[i]) { _glow[i] = next; moving = true; }
            }
            if (moving) Invalidate(); else _glowTimer.Stop();
        };
    }

    // ---------- device list updates coming from the background scan ----------
    internal void OfferDevices(List<string> inputs, List<string> outputs)
    {
        lock (_lock) _pending = (inputs, outputs);
        if (!IsHandleCreated) return;
        try { BeginInvoke(new Action(ApplyPending)); } catch { }
    }

    private void ApplyPending()
    {
        (List<string> Inputs, List<string> Outputs)? pending;
        lock (_lock) { pending = _pending; _pending = null; }
        if (pending is null) return;
        string? mic = InputIndex >= 0 && InputIndex < Inputs.Count ? Inputs[InputIndex] : null;
        string? output = OutputIndex >= 0 && OutputIndex < Outputs.Count ? Outputs[OutputIndex] : null;
        Inputs = pending.Value.Inputs; Outputs = pending.Value.Outputs;
        InputIndex = mic is null ? -1 : Inputs.IndexOf(mic);
        OutputIndex = output is null ? -1 : Outputs.IndexOf(output);
        if (InputIndex < 0 && Inputs.Count > 0) InputIndex = 0;
        if (OutputIndex < 0 && Outputs.Count > 0) OutputIndex = 0;
        Invalidate();
    }

    protected override void OnShown(EventArgs e)
    {
        base.OnShown(e);
        ApplyPending();
        int step = 0;
        var fade = new System.Windows.Forms.Timer { Interval = 15 };
        fade.Tick += (_, _) =>
        {
            step++; Opacity = Math.Min(1.0, step / 10.0);
            if (step >= 10) { fade.Stop(); fade.Dispose(); }
        };
        fade.Start();
    }

    // ---------- mouse ----------
    private static int HitTest(Point p) =>
        MicField.Contains(p) ? 0 : OutField.Contains(p) ? 1 : CheckHit.Contains(p) ? 2 :
        CancelBtn.Contains(p) ? 3 : OkBtn.Contains(p) ? 4 : -1;

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        int hit = HitTest(e.Location);
        if (hit == _hover) return;
        _hover = hit;
        Cursor = hit >= 0 ? _hand : Cursors.Default;
        _glowTimer.Start();
    }

    protected override void OnMouseLeave(EventArgs e)
    {
        base.OnMouseLeave(e);
        _hover = -1; Cursor = Cursors.Default; _glowTimer.Start();
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (e.Button != MouseButtons.Left) return;
        int hit = HitTest(e.Location);
        if (hit < 0) { NativeWindowDrag.Begin(this); return; }
        _pressed = hit; Invalidate();
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        base.OnMouseUp(e);
        int pressed = _pressed; _pressed = -1; Invalidate();
        if (e.Button != MouseButtons.Left || pressed < 0 || HitTest(e.Location) != pressed) return;
        switch (pressed)
        {
            case 0: PickDevice(true); break;
            case 1: PickDevice(false); break;
            case 2: _hear = !_hear; Invalidate(); break;
            case 3: DialogResult = DialogResult.Cancel; Close(); break;
            case 4: Accept(); break;
        }
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
        base.OnKeyDown(e);
        if (e.KeyCode == Keys.Escape) { DialogResult = DialogResult.Cancel; Close(); }
        else if (e.KeyCode == Keys.Enter) Accept();
    }

    private void Accept()
    {
        if (InputIndex < 0 || OutputIndex < 0) return;
        DialogResult = DialogResult.OK; Close();
    }

    private void PickDevice(bool microphone)
    {
        var items = microphone ? Inputs : Outputs;
        if (items.Count == 0) return;
        var field = microphone ? MicField : OutField;
        using var drop = new DropList(items, microphone ? InputIndex : OutputIndex, field.Width, _hand);
        drop.Location = PointToScreen(new Point(field.Left, field.Bottom - 2));
        drop.ShowDialog(this);
        if (drop.Chosen < 0) return;
        if (microphone) InputIndex = drop.Chosen; else OutputIndex = drop.Chosen;
        Invalidate();
    }

    // ---------- painting ----------
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        const TextFormatFlags flags = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine
            | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding;

        string? mic = InputIndex >= 0 && InputIndex < Inputs.Count ? Inputs[InputIndex] : null;
        string? output = OutputIndex >= 0 && OutputIndex < Outputs.Count ? Outputs[OutputIndex] : null;
        TextRenderer.DrawText(g, mic ?? "- Select Microphone...", _font, MicText, mic is null ? HintColor : TextColor, flags);
        TextRenderer.DrawText(g, output ?? "- Select Output Device...", _font, OutText, output is null ? HintColor : TextColor, flags);

        var box = new Rectangle(CheckBoxRect.Left, CheckBoxRect.Top, 26, 26);
        g.DrawImage(_hear ? _checkOn : _checkOff, box);

        for (int id = 0; id < 5; id++) DrawGlow(g, id);
    }

    private void DrawGlow(Graphics g, int id)
    {
        float glow = _glow[id];
        bool pressed = id == _pressed;
        if (glow <= 0.01f && !pressed) return;
        Rectangle area = id switch { 0 => MicField, 1 => OutField, 2 => new Rectangle(CheckBoxRect.Left, CheckBoxRect.Top, 26, 26), 3 => CancelBtn, _ => OkBtn };
        area.Inflate(-2, -2);
        using var path = RoundedRect(area, id == 2 ? 3 : 7);
        if (pressed)
        {
            using var dark = new SolidBrush(Color.FromArgb(90, 0, 0, 0));
            g.FillPath(dark, path);
            return;
        }
        using var fill = new SolidBrush(Color.FromArgb((int)(34 * glow), 255, 255, 255));
        g.FillPath(fill, path);
        if (id <= 1)
        {
            using var edge = new Pen(Color.FromArgb((int)(110 * glow), 210, 214, 224), 1.5f);
            g.DrawPath(edge, path);
        }
    }

    private static GraphicsPath RoundedRect(Rectangle r, int radius)
    {
        int d = radius * 2;
        var path = new GraphicsPath();
        path.AddArc(r.Left, r.Top, d, d, 180, 90);
        path.AddArc(r.Right - d, r.Top, d, d, 270, 90);
        path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
        path.AddArc(r.Left, r.Bottom - d, d, d, 90, 90);
        path.CloseFigure();
        return path;
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) { _glowTimer.Dispose(); _font.Dispose(); _art.Dispose(); _checkOn.Dispose(); _checkOff.Dispose(); }
        base.Dispose(disposing);
    }

    /// <summary>Dark drop-down list used instead of the Windows combo box.</summary>
    internal sealed class DropList : Form
    {
        private const int RowHeight = 26;
        private readonly ListBox _list = new();
        private int _hover = -1;
        internal int Chosen = -1;

        internal DropList(List<string> items, int selected, int width, Cursor hand)
        {
            AutoScaleMode = AutoScaleMode.None;
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            ShowInTaskbar = false;
            KeyPreview = true;
            BackColor = Color.FromArgb(120, 122, 128);   // 1px light border around the list
            Padding = new Padding(1);
            int rows = Math.Min(items.Count, 7);
            ClientSize = new Size(width, rows * RowHeight + 2);

            _list.Dock = DockStyle.Fill;
            _list.BorderStyle = BorderStyle.None;
            _list.BackColor = Color.FromArgb(10, 10, 12);
            _list.DrawMode = DrawMode.OwnerDrawFixed;
            _list.ItemHeight = RowHeight;
            _list.IntegralHeight = false;
            _list.Cursor = hand;
            _list.Items.AddRange(items.Cast<object>().ToArray());
            if (selected >= 0 && selected < items.Count) _list.SelectedIndex = selected;
            _list.HandleCreated += (_, _) => NativeTheme.Dark(_list);
            _list.DrawItem += (_, e) =>
            {
                if (e.Index < 0) return;
                bool lit = e.Index == _hover || (_hover < 0 && (e.State & DrawItemState.Selected) != 0);
                Color back = lit ? Color.FromArgb(58, 59, 64) : (e.Index % 2 == 0 ? Color.FromArgb(10, 10, 12) : Color.FromArgb(24, 24, 26));
                using (var brush = new SolidBrush(back)) e.Graphics.FillRectangle(brush, e.Bounds);
                TextRenderer.DrawText(e.Graphics, items[e.Index], Font,
                    new Rectangle(e.Bounds.X + 8, e.Bounds.Y, e.Bounds.Width - 12, e.Bounds.Height), TextColor,
                    TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
            };
            _list.MouseMove += (_, e) =>
            {
                int index = _list.IndexFromPoint(e.Location);
                if (index == _hover) return;
                _hover = index; _list.Invalidate();
            };
            _list.MouseLeave += (_, _) => { _hover = -1; _list.Invalidate(); };
            _list.MouseUp += (_, e) =>
            {
                int index = _list.IndexFromPoint(e.Location);
                if (e.Button == MouseButtons.Left && index >= 0) { Chosen = index; Close(); }
            };
            Deactivate += (_, _) => Close();
            KeyDown += (_, e) =>
            {
                if (e.KeyCode == Keys.Escape) Close();
                else if (e.KeyCode == Keys.Enter && _list.SelectedIndex >= 0) { Chosen = _list.SelectedIndex; Close(); }
            };
            Controls.Add(_list);
        }
    }
}

/// <summary>"Creative EAX - Loading" screen. Runs on its own thread so the bar keeps gliding while the app loads.</summary>
internal sealed class SplashForm : Form
{
    private readonly Bitmap _art;
    private readonly Rectangle _bar;
    private readonly System.Windows.Forms.Timer _timer = new() { Interval = 12 };
    private volatile float _target;      // where the bar should be heading (set by the loader)
    private volatile float _drawn;       // eased value actually painted
    private volatile bool _fadeOut;
    private float _shimmer, _sweep, _spin;
    private int _frame;
    private readonly Font _statusFont = new("Segoe UI Semibold", 7.5f);

    internal float Drawn => _drawn;

    internal SplashForm(string assets)
    {
        _art = new Bitmap(Path.Combine(assets, "Loading.png"));
        AutoScaleMode = AutoScaleMode.None;
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.CenterScreen;
        ShowInTaskbar = false;
        TopMost = true;
        DoubleBuffered = true;
        BackColor = Color.Black;
        ClientSize = _art.Size;
        Opacity = 0;
        double k = _art.Width / 1024.0;   // the loading bar was measured on the 1024-wide original
        _bar = Rectangle.FromLTRB((int)(145 * k), (int)(435 * k), (int)(881 * k), (int)(463 * k));
        Region = MainForm.RegionFromBitmap(_art);
        string icon = Path.Combine(assets, "AppIcon.ico");
        if (File.Exists(icon)) Icon = new Icon(icon);
        _timer.Tick += OnTick;
        Shown += (_, _) => _timer.Start();
    }

    internal void SetTarget(double value) => _target = (float)Math.Clamp(value, 0, 1);
    internal void FadeOut() => _fadeOut = true;

    private void OnTick(object? sender, EventArgs e)
    {
        if (_fadeOut)
        {
            Opacity -= 0.06;
            if (Opacity <= 0.03) { _timer.Stop(); Close(); return; }
        }
        else if (Opacity < 1) Opacity = Math.Min(1, Opacity + 0.07);

        // Ease toward the target, with a tiny constant creep so the bar never looks frozen while work is happening.
        float goal = _target;
        float next = _drawn + (goal - _drawn) * 0.06f + 0.0006f;
        _drawn = Math.Min(next, goal <= _drawn ? _drawn : goal);
        if (_drawn < goal && _drawn > goal - 0.0008f) _drawn = goal;
        _shimmer += 0.016f;
        if (_shimmer > 1.4f) _shimmer = 0;
        _sweep += 0.011f; if (_sweep > 2.2f) _sweep = 0;     // logo shine: sweeps, then rests
        _spin += 0.16f;                                      // spinner
        _frame++;
        Invalidate();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.DrawImage(_art, 0, 0, _art.Width, _art.Height);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        double k = _art.Width / 1024.0;

        // 1) light that sweeps across the logo plate every couple of seconds
        float t = _sweep / 1.6f;
        if (t <= 1f)
        {
            var logo = Rectangle.FromLTRB((int)(137 * k), (int)(107 * k), (int)(868 * k), (int)(318 * k));
            var saved = g.Save();
            g.SetClip(logo);
            const int bandWidth2 = 140;
            var shine = new Rectangle(logo.Left - bandWidth2 + (int)((logo.Width + bandWidth2) * t), logo.Top, bandWidth2, logo.Height);
            using (var brush = new LinearGradientBrush(shine, Color.Transparent, Color.Transparent, LinearGradientMode.Horizontal))
            {
                brush.InterpolationColors = new ColorBlend
                {
                    Positions = [0f, 0.5f, 1f],
                    Colors = [Color.FromArgb(0, 255, 255, 255), Color.FromArgb(70, 255, 255, 255), Color.FromArgb(0, 255, 255, 255)]
                };
                g.FillRectangle(brush, shine);
            }
            g.Restore(saved);
        }

        // 2) loading spinner next to the word LOADING
        float cx = (float)(361 * k), cy = (float)(380 * k);
        for (int i = 0; i < 10; i++)
        {
            double angle = _spin + i * Math.PI * 2 / 10;
            float x = cx + (float)Math.Cos(angle) * 10f, y = cy + (float)Math.Sin(angle) * 10f;
            int alpha = 35 + (int)(220 * (i + 1) / 10.0);
            using var dot = new SolidBrush(Color.FromArgb(alpha, 205, 208, 214));
            g.FillEllipse(dot, x - 2.3f, y - 2.3f, 4.6f, 4.6f);
        }

        // 3) status line that follows the real progress
        string status = _drawn < 0.25f ? "INITIALIZING SYSTEM" : _drawn < 0.6f ? "LOADING AUDIO ENGINE" : _drawn < 0.97f ? "SCANNING AUDIO DEVICES" : "READY";
        if (status != "READY") status += new string('.', 1 + _frame / 22 % 3);
        var statusArea = new Rectangle((int)(_art.Width / 2.0 - 170), (int)(474 * k), 340, 18);
        TextRenderer.DrawText(g, status, _statusFont, statusArea, Color.FromArgb(150, 152, 158),
            TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.SingleLine);

        int creditAlpha = (int)(255 * Math.Clamp((_drawn - 0.08f) / 0.3f, 0f, 1f));
        if (creditAlpha > 0)
        {
            using var creditBrush = new SolidBrush(Color.FromArgb(creditAlpha, 214, 216, 222));
            using var center = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            g.DrawString("MADE BY 3AH", _statusFont, creditBrush, new RectangleF(0, (int)(497 * k), _art.Width, 20), center);
        }

        int width = (int)(_bar.Width * Math.Clamp(_drawn, 0f, 1f));
        if (width < 3) return;
        var fill = new Rectangle(_bar.X, _bar.Y, width, _bar.Height);
        using (var brush = new LinearGradientBrush(fill, Color.FromArgb(196, 198, 204), Color.FromArgb(74, 76, 82), LinearGradientMode.Vertical))
            g.FillRectangle(brush, fill);
        using (var shine = new Pen(Color.FromArgb(130, 255, 255, 255)))
            g.DrawLine(shine, fill.Left, fill.Top + 1, fill.Right - 1, fill.Top + 1);

        // soft highlight sweeping across the filled part
        var state = g.Save();
        g.SetClip(fill);
        int bandWidth = 90;
        int bandX = fill.Left - bandWidth + (int)((fill.Width + bandWidth) * Math.Min(_shimmer / 1.0f, 1.4f));
        var band = new Rectangle(bandX, fill.Top, bandWidth, fill.Height);
        using (var sweep = new LinearGradientBrush(band, Color.Transparent, Color.Transparent, LinearGradientMode.Horizontal))
        {
            sweep.InterpolationColors = new ColorBlend
            {
                Positions = [0f, 0.5f, 1f],
                Colors = [Color.FromArgb(0, 255, 255, 255), Color.FromArgb(120, 255, 255, 255), Color.FromArgb(0, 255, 255, 255)]
            };
            g.FillRectangle(sweep, band);
        }
        g.Restore(state);

        // segment gaps and a glowing leading edge
        using (var gap = new Pen(Color.FromArgb(18, 18, 20), 2))
            for (int x = fill.Left + 12; x < fill.Right; x += 12) g.DrawLine(gap, x, fill.Top, x, fill.Bottom);
        using (var edge = new Pen(Color.FromArgb(200, 235, 238, 245), 2))
            g.DrawLine(edge, fill.Right - 1, fill.Top, fill.Right - 1, fill.Bottom);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) { _timer.Dispose(); _art.Dispose(); _statusFont.Dispose(); }
        base.Dispose(disposing);
    }
}

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        string assets = Path.Combine(AppContext.BaseDirectory, "Assets");

        // 1) Loading screen on its own UI thread, so its animation never stalls while the app loads.
        SplashForm? splash = null;
        if (File.Exists(Path.Combine(assets, "Loading.png")))
        {
            var created = new ManualResetEventSlim();   // intentionally not disposed: the thread may still signal it
            var thread = new Thread(() =>
            {
                try { splash = new SplashForm(assets); } catch { splash = null; }
                created.Set();
                if (splash is not null) Application.Run(splash);
            }) { IsBackground = true, Name = "Splash" };
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            created.Wait(3000);
        }
        var clock = System.Diagnostics.Stopwatch.StartNew();
        splash?.SetTarget(0.18);

        // 2) Scan audio devices in the background while the window is built.
        Task<DeviceSnapshot> scan = DeviceCache.Refresh();
        var main = new MainForm();
        splash?.SetTarget(0.55);

        DeviceSnapshot? snapshot = null;
        try { snapshot = scan.Wait(10000) ? scan.Result : null; } catch { snapshot = null; }
        main.LoadDevices(snapshot);
        splash?.SetTarget(1.0);

        // 3) Let the bar finish smoothly (about 2.6 s in total), then cross-fade into the app.
        while (splash is not null && (clock.ElapsedMilliseconds < 2600 || splash.Drawn < 0.985f))
        {
            Thread.Sleep(20);
            if (clock.ElapsedMilliseconds > 9000) break;
        }
        splash?.FadeOut();
        Application.Run(main);
    }
}
